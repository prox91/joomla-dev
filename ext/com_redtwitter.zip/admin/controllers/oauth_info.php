<?php
/**
 * @version    1.0.0
 * @package    Com_Redtwitter
 * @author     Ronni K. G. Christiansen<email@redweb.dk> - http://www.redcomponent.com
 * @copyright  Copyright (C) 2010 redCOMPONENT.com. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 *             Developed by email@recomponent.com - redCOMPONENT.com
 */

// No direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controllerform');
include_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/redtwitter.php';

/**
 * Class RedtwitterControllerOauth_Info
 */
class RedtwitterControllerOauth_Info extends JControllerForm
{
	/**
	 * @param array $default
	 */
	public function __construct($default = array())
	{
		parent::__construct($default);
	}

	/**
	 * Proxy for getModel.
	 * @since    1.6
	 */
	public function getModel($name = 'Oauth_Info', $prefix = 'RedtwitterModel')
	{
		$model = parent::getModel($name, $prefix, array('ignore_request' => true));

		return $model;
	}

	/**
	 * @return bool|void
	 */
	public function cancel()
	{
		$this->redirect = "index.php?option=com_redtwitter";
	}

	/**
	 *  Get access token from twitter
	 */
	public function generateToken()
	{
		$input = JFactory::getApplication()->input;
		$jform = $input->get('jform', '', 'ARRAY');

		if ($jform['consumer_key'] != "" && $jform['consumer_secret'] != "")
		{
			$access_token = RedtwitterHelper::getAccessToken($jform['consumer_key'], $jform['consumer_secret']);
			$data['access_token'] = $access_token;

			$data = array_merge($jform, $data);
			$this->getModel()->updateToken($data);

			$session = JFactory::getSession();
			$session->set('generated_token_result', true);

			$this->redirect = "index.php?option=com_redtwitter&view=oauth_info";


			// Get time line
			//$url = "https://api.twitter.com/1.1/users/show.json?screen_name=amazon";
			$url = "https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=amazon&count=2";

			$header = array(
				'Authorization' => 'Bearer '.$access_token,
			);

			$http = RedHttpFactory::getHttp();
			$response = $http->get($url, $header);

			echo '<pre/>';
			print_r($response);

			exit();

		}


		/*
		if ($jform['consumer_key'] != "" && $jform['consumer_secret'] != "")
		{
			require_once(JPATH_SITE . "/components/com_redtwitter/libs/twitteroauth/OAuth.php");
			require_once(JPATH_SITE . "/components/com_redtwitter/libs/twitteroauth/twitteroauth.php");

			$twitterObj = new TwitterOAuth($jform['consumer_key'], $jform['consumer_secret']);
			$request_token = $twitterObj->getRequestToken();

			$session = JFactory::getSession();
			$session->set('oauth_form', $jform);
			$session->set('oauth_token_secret', $request_token['oauth_token_secret']);

			$request_link = $twitterObj->getAuthorizeURL($request_token);
			header("location: $request_link");
			exit();
		}
		*/
	}

	/**
	 *    Save the access token to database
	 */
	public function update_token()
	{
		$oauth_verifier = JRequest::getVar('oauth_verifier');
		$oauth_token = JRequest::getVar('oauth_token');
		if ($oauth_verifier != "" && $oauth_token != "")
		{
			$session = JFactory::getSession();

			$oauth_form = $session->get('oauth_form');
			$oauth_token_secret = $session->get('oauth_token_secret');

			require_once(JPATH_SITE . "/components/com_redtwitter/libs/twitteroauth/OAuth.php");
			require_once(JPATH_SITE . "/components/com_redtwitter/libs/twitteroauth/twitteroauth.php");

			$twitterObj = new TwitterOAuth($oauth_form['consumer_key'], $oauth_form['consumer_secret'], $oauth_token, $oauth_token_secret);
			$tok = $twitterObj->getAccessToken($oauth_verifier);

			if (is_array($tok))
			{
				$data = array_merge($oauth_form, $tok);
				$this->getModel()->updateToken($data);

				$session->set('generated_token_result', true);
			}

			$session->clear('oauth_token_secret');
			$session->clear('oauth_form');
		}

		$this->redirect = "index.php?option=com_redtwitter&view=oauth_info";
	}
}
