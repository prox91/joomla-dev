<?php
/**
 * @package     redSocialstream
 * @subpackage  Views
 *
 * @copyright   Copyright (C) 2012 - 2013 redCOMPONENT.com. All rights reserved.
 * @license     GNU General Public License version 2 or later, see LICENSE.
 */
defined('_JEXEC') or die ('restricted access');
jimport('joomla.application.component.view');
class redsocialstreamViewgroup extends JView
{ 
	function display ($tpl=null)
	{
		$mainframe = JFactory::getApplication();
		$params = $mainframe->getparams();
		$groupeid = "";
		$groupeid = JRequest::getVar('groupid');
		$profiletypeid = "";
		$profiletypeid = JRequest::getVar('profiletypeid');
		$doc =& JFactory::getDocument();
		$doc->addStyleSheet("components/com_redsocialstream/assets/css/redsocialstream_group.css");
		$session =& JFactory::getSession();
		$uri =& JFactory::getURI();
		$user =& JFactory::getUser();	
		$model =& $this->getModel();	
		$data = array();
		$feedlists = "";
		$limit = "";
		$limit = JRequest::getVar('limit');
		if($limit == "")
		{
			$limit = $params->get('feedlimit');
		}

		//$feedlists=$model->getfeedslist($groupeid,$profiletypeid);
		if(JRequest::getVar('task') == "save")
		{
			$oauth_token = JRequest::getVar('oauth_token');
			$data = $model->getfeeds($groupeid,$profiletypeid,$oauth_token); 
			echo "ok";
		}
		if(JRequest::getVar('task') == "getajaxposts")
		{
			if($groupeid !=array())
			{
				$group=$model->getgroupdata($groupeid);
				$this->assignRef('groupinfo',$group);
			}
			$limit = "";
			echo $limit = JRequest::getVar('limit');
			if($limit == "")
			{
			$limit = $params->get('feedlimit');
			}
			$this->assignRef('posts',$model->getposts($groupeid,$profiletypeid,$limit));
			$this->assignRef('limit', $limit);
			$tpl = "ajaxposts";
			parent::display($tpl);
		}
		
	}
}
?> 

