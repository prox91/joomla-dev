<?php
defined ('_JEXEC') or die ('Restricted access');

$controller = JRequest::getCmd('view','redsocialstream' );

//set the default controller page
if(!file_exists(JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php')){
	$controller='redsocialstream';
	//JRequest::setVar('view','redsocialstream' );
}
//print_r($controller);
//set the controller page 
require_once (JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php');

// Create the controller helloworldController 
$classname  = $controller.'controller';

//create a new class of classname and set the default task:display
$controller = new $classname( array('default' => 'display') );

// Perform the Request task
$controller->execute( JRequest::getCmd('task' ));

// Redirect if set by the controller
$controller->redirect(); 
?>