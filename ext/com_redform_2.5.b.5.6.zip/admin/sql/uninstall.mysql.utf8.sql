DROP TABLE IF EXISTS  
	`#__rwf_configuration`,
	`#__rwf_fields`,
	`#__rwf_forms`,
	`#__rwf_submitters`,
	`#__rwf_values`,
	`#__rwf_mailinglists` ,
	`#__rwf_payment`
	;
