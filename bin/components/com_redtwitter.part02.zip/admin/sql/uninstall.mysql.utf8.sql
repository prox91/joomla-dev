DROP TABLE IF EXISTS `#__redtwitter_followed_profiles`;

DROP TABLE IF EXISTS `#__redtwitter_oauth_info`;