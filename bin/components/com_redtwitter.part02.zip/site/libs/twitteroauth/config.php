<?php
/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', '8ErgG8KfoEStRltpo76fw');
define('CONSUMER_SECRET', 'ztACDEIm1oYNGpuDR4JXJZMBrvDia5TIhV93nFJmFIo');
define('OAUTH_TOKEN', '631697128-8P0RyekbyWDPeOrODTgNNP9ZSdalzaqmJqPtwMij');
define('OAUTH_TOKEN_SECRET', 'VGrNtcVFXcVq72qs26z3GDI1ClcVijmSotFwZtucSbg');
define('OAUTH_CALLBACK', 'https://api.twitter.com/oauth/request_token');