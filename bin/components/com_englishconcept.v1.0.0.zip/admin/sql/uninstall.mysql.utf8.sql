DROP TABLE IF EXISTS `#__lesson`;
DROP TABLE IF EXISTS `#__lesson_script`;
DROP TABLE IF EXISTS `#__lesson_key_structures`;
DROP TABLE IF EXISTS `#__lesson_comprehension`;
DROP TABLE IF EXISTS `#__lesson_special_difficulties`;
DROP TABLE IF EXISTS `#__lesson_exercises`;