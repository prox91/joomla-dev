<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Ngoc Nha
 * Date: 4/6/13
 * Time: 5:45 PM
 * To change this template use File | Settings | File Templates.
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// Import Joomla Form Controller library
jimport('legacy.controller.form');

/**
 * Class HelloWorldControllerHelloWorld
 */
class HelloWorldControllerHelloWorld extends JControllerForm
{

}