DROP TABLE IF EXISTS `#__redtwitter_followed_profiles`;
