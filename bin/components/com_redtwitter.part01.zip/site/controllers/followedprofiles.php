<?php  defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.controller' );
class FollowedprofilesController extends JControllerLegacy
{
	function __construct( $default = array())
	{
	 
		parent::__construct( $default );
	}
	
}
   
