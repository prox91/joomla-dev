DROP TABLE IF EXISTS #__twitter_consumer;
DROP TABLE IF EXISTS #__twitter_mapping;
