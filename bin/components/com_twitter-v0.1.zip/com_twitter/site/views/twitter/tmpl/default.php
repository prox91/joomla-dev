<?php
/**
 * @version	0.1
 * @package	twitter
 * @author Mobilada.com
 * @author mail	info@mobilada.com
 * @copyright	Copyright (C) 2009 Mobilada.com - All rights reserved.
 * @license		GNU/GPL
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
twitter default template
