<?php
/**
 * @version	0.1
 * @package	twitter
 * @author Mobilada.com
 * @author mail	info@mobilada.com
 * @copyright	Copyright (C) 2009 Mobilada.com - All rights reserved.
 * @license		GNU/GPL
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view' );

class twitterViewMapping extends Jview
{

	function __construct()
	{
		parent::__construct();
	}
	
	function display($tpl = null)
	{
		parent::display($tpl);
	}
	
}
